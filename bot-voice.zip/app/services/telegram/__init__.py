"""Telegram service package."""
