"""Pure utility helpers."""
