"""Application tests."""
