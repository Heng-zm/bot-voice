"""Extracted Telegram handler implementations.

These are live runtime handlers; app.legacy now contains compatibility wrappers only.
"""

from __future__ import annotations

# Transitional V4.1 modules bind remaining legacy helpers at runtime.
# ruff: noqa: F821
from app.services.telegram._legacy_runtime import legacy_bound_handler
from app.services.telegram.security import (
    _ADMIN_ONLY_COMMANDS,
    _security_notice_once,
    _telegram_command_name,
)


@legacy_bound_handler
async def _telegram_rate_limit_guard(update: Any, context: Any) -> None:
    if not isinstance(update, Update):
        return
    # Channel posts are managed broadcasts by channel administrators/editors;
    # do not throttle them under standard user DM rate-limits.
    if getattr(update, "channel_post", None) is not None:
        return
    user = getattr(update, "effective_user", None)
    if user and _is_admin(int(user.id)):
        # Admins are exempt from rate limiting to maintain uninterrupted emergency control
        return

    key = _update_rate_limit_key(update)
    now = time.monotonic()
    
    # 1. Check Anti-Flood Cooldown
    with _RATE_LIMIT_MEMORY_THREAD_LOCK:
        cooldown_until = getattr(_RATE_LIMIT_NOTICE_MEMORY, "_flood_cooldowns", {}).get(key, 0.0)
        if now < cooldown_until:
            _metric_inc("flood_blocked")
            raise ApplicationHandlerStop

    allowed, _remaining = await _rate_limit_check(key, _run_state_user_rate_limit(), _run_state_user_rate_window())
    if allowed:
        return

    _metric_inc("rate_limited")
    should_send_notice = False
    flood_detected = False

    with _RATE_LIMIT_MEMORY_THREAD_LOCK:
        if not hasattr(_RATE_LIMIT_NOTICE_MEMORY, "_flood_cooldowns"):
            _RATE_LIMIT_NOTICE_MEMORY._flood_cooldowns = {}
        if not hasattr(_RATE_LIMIT_NOTICE_MEMORY, "_violation_counts"):
            _RATE_LIMIT_NOTICE_MEMORY._violation_counts = {}

        violations = _RATE_LIMIT_NOTICE_MEMORY._violation_counts.get(key, 0) + 1
        _RATE_LIMIT_NOTICE_MEMORY._violation_counts[key] = violations

        if violations >= 6:
            # Excessive spam: trigger 45-second progressive cooldown
            cooldown_s = min(300.0, 45.0 * (violations - 5))
            _RATE_LIMIT_NOTICE_MEMORY._flood_cooldowns[key] = now + cooldown_s
            flood_detected = True

        last = _RATE_LIMIT_NOTICE_MEMORY.get(key, 0.0)
        if now - last >= USER_RATE_LIMIT_NOTICE_COOLDOWN_S:
            _RATE_LIMIT_NOTICE_MEMORY[key] = now
            should_send_notice = True
            if len(_RATE_LIMIT_NOTICE_MEMORY) > 10_000:
                stale_before = now - max(USER_RATE_LIMIT_NOTICE_COOLDOWN_S * 4, 300.0)
                for old_key, old_ts in list(_RATE_LIMIT_NOTICE_MEMORY.items()):
                    if old_ts < stale_before:
                        _RATE_LIMIT_NOTICE_MEMORY.pop(old_key, None)
                while len(_RATE_LIMIT_NOTICE_MEMORY) > 10_000:
                    _RATE_LIMIT_NOTICE_MEMORY.pop(next(iter(_RATE_LIMIT_NOTICE_MEMORY)), None)

    if should_send_notice:
        chat = getattr(update, "effective_chat", None)
        msg = getattr(update, "effective_message", None)
        # Never send rate-limit warning messages into public broadcast channels
        if msg is not None and getattr(chat, "type", None) != "channel":
            with suppress(Exception):
                if flood_detected:
                    await safe_send(lambda: msg.reply_text(
                        "🛑 <b>ការផ្ញើសារលឿនពេក (Anti-Spam)</b>\n\n"
                        "ប្រព័ន្ធបានដាក់ Cooldown បណ្តោះអាសន្ន ៤៥ វិនាទី។ សូមរង់ចាំបន្តិចមុនពេលផ្ញើសារបន្ទាប់។",
                        parse_mode="HTML"
                    ))
                else:
                    await safe_send(lambda: msg.reply_text(_runtime_admin_notice_text()))
    raise ApplicationHandlerStop


@legacy_bound_handler
async def _telegram_user_security_guard(update: Any, context: Any) -> None:
    """Cheap global user-safety gate before expensive handlers.

    - Blocks non-admin access to admin commands/callbacks.
    """
    if not isinstance(update, Update):
        return
    user = update.effective_user
    if user is None:
        return
    user_id = int(user.id)
    if _is_admin(user_id):
        return

    query = update.callback_query
    data = str(getattr(query, "data", "") or "") if query is not None else ""
    admin_callback_prefixes = ("admin_", "needs_", "api_", "rtadmin_", "user_", "users_", "history_", "sched_", "bc_", "admin_report_", "cfg_", "cfg_cat:", "cfg_set:")
    if _env_bool("ADMIN_CALLBACK_GUARD_ENABLED", True) and data.startswith(admin_callback_prefixes):
        _metric_inc("admin_denied")
        await _security_notice_once(update, f"admin_cb:{user_id}", '⛔ សម្រាប់អ្នកគ្រប់គ្រងប៉ុណ្ណោះ។', alert=True)
        raise ApplicationHandlerStop

    cmd = _telegram_command_name(update)
    if cmd in _ADMIN_ONLY_COMMANDS:
        _metric_inc("admin_denied")
        await _security_notice_once(update, f"admin_cmd:{user_id}", "⛔ ពាក្យបញ្ជានេះសម្រាប់ Admin ប៉ុណ្ណោះ។")
        raise ApplicationHandlerStop
    if cmd in {"security", "privacy", "deleteme"}:
        return


@legacy_bound_handler
async def _drop_stale_updates(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Drop old message updates received before bot started.

    FIX: For callback_query updates, we intentionally do NOT drop them based on
    message date — the message date is when the original message was sent, not
    when the user tapped the button. Dropping callbacks based on message age
    would break buttons on messages sent before the bot restarted. We only drop
    stale *message* updates.
    """
    # Webhook mode must not drop old message timestamps. During cold starts,
    # this app returns 503 until Telegram is ready, and Telegram may retry the
    # same update later with the original message date.  Dropping it here would
    # lose user messages after a slow Render restart/deploy.
    if "_run_state_bot_mode" in globals() and _run_state_bot_mode() == "WEBHOOK":
        return

    if _BOT_START_TIME == 0.0:
        return

    # Only filter plain messages (not callbacks)
    msg = update.message or update.edited_message or update.channel_post
    if msg and getattr(msg, "date", None) and msg.date.timestamp() < (
        _BOT_START_TIME - _STALE_GRACE_S
    ):
        logger.debug(f"Dropping stale message/channel update (id={update.update_id})")
        raise ApplicationHandlerStop


@legacy_bound_handler
async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    err = getattr(context, "error", None)
    if err is None:
        return

    if isinstance(err, ApplicationHandlerStop) or _is_nonfatal_telegram_edit_error(err):
        logger.debug("Ignored non-fatal Telegram handler condition: %s", err)
        return

    err_str = str(err).lower()
    if any(term in err_str for term in (
        "bad gateway",
        "gateway timeout",
        "timed out",
        "timedout",
        "readtimeout",
        "connect timeout",
        "server disconnected",
        "connection reset",
        "network is unreachable",
        "502",
        "504",
    )):
        logger.warning("Telegram transient upstream network issue in handler: %s", err)
        return

    _metric_inc("errors")
    _record_admin_error("telegram_error_handler", str(err), level="ERROR", context=type(update).__name__)
    logger.error(
        "Unhandled exception: %s",
        err,
        exc_info=(type(err), err, getattr(err, "__traceback__", None)),
    )

    if isinstance(update, Update) and update.effective_message:
        chat = getattr(update, "effective_chat", None)
        if getattr(chat, "type", None) == "private":
            with suppress(Exception):
                await safe_send(lambda: update.effective_message.reply_text(
                    "⚠️ មានបញ្ហាបច្ចេកទេស។ Bot នៅដំណើរការ — សូមព្យាយាមម្តងទៀត។"
                ))


__all__ = [
    '_drop_stale_updates',
    '_telegram_rate_limit_guard',
    '_telegram_user_security_guard',
    'error_handler',
]
